import React, { useState, useEffect, useCallback } from 'react';
import { Post, Role } from '../types';
import { useAuth } from '../hooks/useAuth';
import * as api from '../services/mockApi';
import PostCard from './PostCard';
import Modal from './Modal';

const DashboardPage: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchPosts = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const fetchedPosts = await api.getPosts();
      setPosts(fetchedPosts);
    } catch (e) {
      setError('Failed to fetch posts.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  const onUpdatePost = useCallback(async (postId: string, title: string, content: string) => {
    if (!user) throw new Error("User not authenticated");
    await api.updatePost(postId, title, content, user);
    await fetchPosts(); // Refetch after update
  }, [user, fetchPosts]);

  const onDeletePost = useCallback(async (postId: string) => {
    if (!user) throw new Error("User not authenticated");
    await api.deletePost(postId, user);
    await fetchPosts(); // Refetch after delete
  }, [user, fetchPosts]);


  const canCreate = user?.role === Role.ADMIN || user?.role === Role.EDITOR;

  const handleOpenCreateModal = () => {
    setNewPostTitle('');
    setNewPostContent('');
    setIsCreateModalOpen(true);
  };

  const handleCloseCreateModal = () => {
    setIsCreateModalOpen(false);
  };

  const handleCreatePost = async () => {
    if (!user || !newPostTitle || !newPostContent) return;
    setIsSubmitting(true);
    try {
      await api.createPost(newPostTitle, newPostContent, user);
      await fetchPosts();
      handleCloseCreateModal();
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    } finally {
        setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        {canCreate && (
           <button
            onClick={handleOpenCreateModal}
            className="px-4 py-2 font-semibold text-white bg-teal-600 rounded-md shadow-sm hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors"
          >
            Create New Post
          </button>
        )}
      </div>

      {isLoading && <p className="text-center">Loading posts...</p>}
      {error && <p className="text-center text-red-500">{error}</p>}
      
      {!isLoading && !error && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {posts.map(post => (
            <PostCard key={post.id} post={post} onUpdate={onUpdatePost} onDelete={onDeletePost} />
          ))}
        </div>
      )}

      <Modal isOpen={isCreateModalOpen} onClose={handleCloseCreateModal} title="Create a New Post">
        <form onSubmit={(e) => { e.preventDefault(); handleCreatePost(); }}>
            <div className="space-y-4">
                <div>
                    <label htmlFor="post-title" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                    <input
                        type="text"
                        id="post-title"
                        value={newPostTitle}
                        onChange={(e) => setNewPostTitle(e.target.value)}
                        required
                        className="mt-1 block w-full px-3 py-2 text-gray-900 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"
                    />
                </div>
                <div>
                    <label htmlFor="post-content" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Content</label>
                    <textarea
                        id="post-content"
                        rows={4}
                        value={newPostContent}
                        onChange={(e) => setNewPostContent(e.target.value)}
                        required
                        className="mt-1 block w-full px-3 py-2 text-gray-900 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"
                    />
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                    <button type="button" onClick={handleCloseCreateModal} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 dark:bg-slate-600 dark:text-gray-200 dark:border-slate-500 dark:hover:bg-slate-500">Cancel</button>
                    <button type="submit" disabled={isSubmitting || !newPostTitle || !newPostContent} className="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md shadow-sm hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:bg-teal-400 disabled:cursor-not-allowed">
                        {isSubmitting ? 'Creating...' : 'Create Post'}
                    </button>
                </div>
            </div>
        </form>
      </Modal>
    </div>
  );
};

export default DashboardPage;