import React, { useState, useEffect, useCallback } from 'react';
import { User, Role } from '../types';
import * as api from '../services/mockApi';
import { useAuth } from '../hooks/useAuth';
import Modal from './Modal';
import Tooltip from './Tooltip';

const UserManagementPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newRole, setNewRole] = useState<Role>(Role.VIEWER);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchUsers = useCallback(async () => {
    if (!user) return;
    setIsLoading(true);
    setError(null);
    try {
      const fetchedUsers = await api.getUsers(user);
      setUsers(fetchedUsers);
    } catch (e) {
      setError('Failed to fetch users. You might not have permission.');
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);
  
  const handleOpenModal = (userToEdit: User) => {
    setSelectedUser(userToEdit);
    setNewRole(userToEdit.role);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const handleRoleChangeSubmit = async () => {
    if (!selectedUser || !user) return;
    setIsSubmitting(true);
    try {
      await api.updateUserRole(selectedUser.id, newRole, user);
      handleCloseModal();
      fetchUsers(); // Refresh user list
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };


  return (
    <div className="container mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">User Management</h1>
      
      {isLoading && <p>Loading users...</p>}
      {error && <p className="text-red-500">{error}</p>}

      {!isLoading && !error && (
        <div className="bg-white dark:bg-slate-800 shadow-lg rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Email</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Role</th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
              {users.map((u) => (
                <tr key={u.id} className="even:bg-slate-50 dark:even:bg-slate-800/50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{u.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{u.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        u.role === 'ADMIN' ? 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' :
                        u.role === 'EDITOR' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300' :
                        'bg-teal-100 text-teal-800 dark:bg-teal-900/50 dark:text-teal-300'
                    }`}>
                        {u.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                     <Tooltip text={user?.id === u.id ? "Admins cannot change their own role" : "Change user role"}>
                        <button 
                            onClick={() => handleOpenModal(u)} 
                            disabled={user?.id === u.id}
                            className="text-teal-600 hover:text-teal-900 dark:text-teal-400 dark:hover:text-teal-300 disabled:text-gray-400 dark:disabled:text-gray-600 disabled:cursor-not-allowed transition-colors font-semibold"
                        >
                            Change Role
                        </button>
                     </Tooltip>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selectedUser && (
        <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={`Change role for ${selectedUser.name}`}>
          <div className="space-y-4">
            <p className="text-gray-700 dark:text-gray-300">Select a new role for <span className="font-semibold">{selectedUser.email}</span>.</p>
            <div>
              <label htmlFor="role-select-modal" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Role
              </label>
              <select
                id="role-select-modal"
                value={newRole}
                onChange={(e) => setNewRole(e.target.value as Role)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm rounded-md dark:bg-slate-700 dark:border-slate-600 dark:text-white"
              >
                <option value={Role.ADMIN}>Admin</option>
                <option value={Role.EDITOR}>Editor</option>
                <option value={Role.VIEWER}>Viewer</option>
              </select>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <button
                type="button"
                onClick={handleCloseModal}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 dark:bg-slate-600 dark:text-gray-200 dark:border-slate-500 dark:hover:bg-slate-500"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleRoleChangeSubmit}
                disabled={isSubmitting}
                className="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md shadow-sm hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:bg-teal-400 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default UserManagementPage;