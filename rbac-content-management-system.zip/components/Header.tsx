import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Role } from '../types';

const Header: React.FC = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="bg-white dark:bg-slate-800 shadow-sm border-b border-slate-200 dark:border-slate-700 sticky top-0 z-30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/dashboard" className="text-2xl font-bold text-teal-600 dark:text-teal-400">
              CMS
            </Link>
            <nav className="hidden md:flex ml-10 space-x-8">
              {isAuthenticated && (
                <Link to="/dashboard" className="text-gray-500 dark:text-gray-300 hover:text-teal-600 dark:hover:text-white transition-colors">
                  Dashboard
                </Link>
              )}
              {user?.role === Role.ADMIN && (
                <Link to="/users" className="text-gray-500 dark:text-gray-300 hover:text-teal-600 dark:hover:text-white transition-colors">
                  User Management
                </Link>
              )}
            </nav>
          </div>
          <div className="flex items-center">
            {isAuthenticated && user ? (
              <div className="flex items-center space-x-4">
                <div className="text-right">
                    <p className="font-medium text-gray-800 dark:text-white">{user.name}</p>
                    <span className="text-sm font-semibold text-teal-600 dark:text-teal-400">{user.role}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 focus:ring-offset-slate-100 dark:focus:ring-offset-slate-800 transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link to="/login" className="text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white transition-colors">
                Login
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;