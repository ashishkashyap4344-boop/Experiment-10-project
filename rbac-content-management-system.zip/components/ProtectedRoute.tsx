
import React, { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Role } from '../types';

interface ProtectedRouteProps {
  children: ReactNode;
  allowedRoles: Role[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const { user, isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    // Redirect them to the /login page, but save the current location they were
    // trying to go to. This allows us to send them along to that page after they
    // log in, which is a nicer user experience.
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (!user || !allowedRoles.includes(user.role)) {
     // User is authenticated but does not have the required role
    return (
        <div className="text-center p-10">
            <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">You do not have permission to view this page.</p>
            <p className="mt-1 text-sm text-gray-500">Your role is: <span className="font-semibold">{user.role}</span>. Required roles: {allowedRoles.join(', ')}</p>
        </div>
    );
  }

  return <>{children}</>;
};

export default ProtectedRoute;
