import React, { useState } from 'react';
import { Post, Role } from '../types';
import { useAuth } from '../hooks/useAuth';
import Tooltip from './Tooltip';
import Modal from './Modal';

interface PostCardProps {
  post: Post;
  onUpdate: (postId: string, title: string, content: string) => Promise<void>;
  onDelete: (postId: string) => Promise<void>;
}

const EditIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>
);

const DeleteIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
);


const PostCard: React.FC<PostCardProps> = ({ post, onUpdate, onDelete }) => {
  const { user } = useAuth();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editedTitle, setEditedTitle] = useState(post.title);
  const [editedContent, setEditedContent] = useState(post.content);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);

  if (!user) return null;

  const isOwner = post.authorId === user.id;
  const isAdmin = user.role === Role.ADMIN;

  const canEdit = isAdmin || (user.role === Role.EDITOR && isOwner);
  const canDelete = isAdmin || (user.role === Role.EDITOR && isOwner);

  const handleOpenEditModal = () => {
    setEditedTitle(post.title);
    setEditedContent(post.content);
    setIsEditModalOpen(true);
  };

  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
  };

  const handleEditSubmit = async () => {
    if (!editedTitle || !editedContent) return;
    setIsSubmitting(true);
    try {
      await onUpdate(post.id, editedTitle, editedContent);
      handleCloseEditModal();
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleDeleteClick = () => {
    setIsConfirmDeleteOpen(true);
  };

  const handleConfirmDelete = async () => {
    setIsSubmitting(true);
    try {
      await onDelete(post.id);
      setIsConfirmDeleteOpen(false);
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };


  return (
    <>
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden flex flex-col justify-between transition-shadow duration-300 hover:shadow-2xl border border-slate-200 dark:border-slate-700">
        <div className="p-6">
          <div className="flex justify-between items-start">
              <div className="flex-1 pr-4">
                   <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{post.title}</h3>
                   <p className="text-sm text-gray-500 dark:text-gray-400">By {post.authorName}</p>
              </div>
               <div className="flex space-x-1 flex-shrink-0">
                  <Tooltip text={canEdit ? "Edit Post" : "You don't have permission to edit"}>
                    <button onClick={handleOpenEditModal} disabled={!canEdit} className="p-2 rounded-full text-gray-500 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:text-gray-300 dark:disabled:text-gray-600 disabled:cursor-not-allowed transition-colors">
                      <EditIcon/>
                    </button>
                  </Tooltip>
                  <Tooltip text={canDelete ? "Delete Post" : "You don't have permission to delete"}>
                    <button onClick={handleDeleteClick} disabled={!canDelete} className="p-2 rounded-full text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 disabled:text-red-300 dark:disabled:text-red-700 disabled:cursor-not-allowed transition-colors">
                      <DeleteIcon/>
                    </button>
                  </Tooltip>
              </div>
          </div>
          
          <p className="text-gray-700 dark:text-gray-300 mt-4 text-base">{post.content}</p>
        </div>
        <div className="bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700 px-6 py-3 text-xs text-gray-500 dark:text-gray-400">
          Updated: {new Date(post.updatedAt).toLocaleString()}
        </div>
      </div>
      <Modal isOpen={isEditModalOpen} onClose={handleCloseEditModal} title="Edit Post">
        <form onSubmit={(e) => { e.preventDefault(); handleEditSubmit(); }}>
            <div className="space-y-4">
                <div>
                    <label htmlFor={`edit-title-${post.id}`} className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                    <input
                        type="text"
                        id={`edit-title-${post.id}`}
                        value={editedTitle}
                        onChange={(e) => setEditedTitle(e.target.value)}
                        required
                        className="mt-1 block w-full px-3 py-2 text-gray-900 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"
                    />
                </div>
                <div>
                    <label htmlFor={`edit-content-${post.id}`} className="block text-sm font-medium text-gray-700 dark:text-gray-300">Content</label>
                    <textarea
                        id={`edit-content-${post.id}`}
                        rows={4}
                        value={editedContent}
                        onChange={(e) => setEditedContent(e.target.value)}
                        required
                        className="mt-1 block w-full px-3 py-2 text-gray-900 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"
                    />
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                    <button type="button" onClick={handleCloseEditModal} className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 dark:bg-slate-600 dark:text-gray-200 dark:border-slate-500 dark:hover:bg-slate-500">Cancel</button>
                    <button type="submit" disabled={isSubmitting || !editedTitle || !editedContent} className="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md shadow-sm hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:bg-teal-400 disabled:cursor-not-allowed">
                        {isSubmitting ? 'Saving...' : 'Save Changes'}
                    </button>
                </div>
            </div>
        </form>
      </Modal>

       <Modal isOpen={isConfirmDeleteOpen} onClose={() => setIsConfirmDeleteOpen(false)} title="Confirm Deletion">
        <div className="space-y-4">
            <p className="text-gray-700 dark:text-gray-300">
                Are you sure you want to permanently delete this post? This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-2 pt-2">
                <button 
                    type="button" 
                    onClick={() => setIsConfirmDeleteOpen(false)} 
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 dark:bg-slate-600 dark:text-gray-200 dark:border-slate-500 dark:hover:bg-slate-500"
                >
                    Cancel
                </button>
                <button 
                    type="button" 
                    onClick={handleConfirmDelete} 
                    disabled={isSubmitting} 
                    className="px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:bg-red-400 disabled:cursor-not-allowed"
                >
                    {isSubmitting ? 'Deleting...' : 'Delete Post'}
                </button>
            </div>
        </div>
      </Modal>
    </>
  );
};

export default PostCard;