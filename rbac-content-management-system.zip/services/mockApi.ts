import { Post, User, Role } from '../types';

// --- MOCK DATABASE (Simulating a persistent data store like MongoDB) ---

export const MOCK_USERS: User[] = [
  { id: 'user-1', name: 'Alice Admin', email: 'admin@example.com', role: Role.ADMIN },
  { id: 'user-2', name: 'Bob Editor', email: 'editor@example.com', role: Role.EDITOR },
  { id: 'user-3', name: 'Charlie Viewer', email: 'viewer@example.com', role: Role.VIEWER },
];

let MOCK_POSTS: Post[] = [
  {
    id: 'post-1',
    title: 'The Future of AI',
    content: 'Exploring the advancements and implications of artificial intelligence in the modern world.',
    authorId: 'user-1', // Alice Admin
    authorName: 'Alice Admin',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'post-2',
    title: 'A Guide to Sustainable Living',
    content: 'Practical tips and tricks for reducing your carbon footprint and living a more eco-friendly lifestyle.',
    authorId: 'user-2', // Bob Editor
    authorName: 'Bob Editor',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
    {
    id: 'post-3',
    title: 'The Art of Minimalist Design',
    content: 'How "less is more" can lead to more effective and beautiful user interfaces.',
    authorId: 'user-2', // Bob Editor
    authorName: 'Bob Editor',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

// --- MOCK API FUNCTIONS ---

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

// READ operations are allowed for all authenticated users
export const getPosts = async (): Promise<Post[]> => {
  await delay(500);
  return [...MOCK_POSTS].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

export const getUsers = async (currentUser: User): Promise<User[]> => {
  await delay(500);
  if (currentUser.role !== Role.ADMIN) {
    throw new Error('Forbidden');
  }
  return [...MOCK_USERS];
};

export const updateUserRole = async (userId: string, newRole: Role, currentUser: User): Promise<User> => {
  await delay(500);

  // RBAC Check: Only Admins can change roles
  if (currentUser.role !== Role.ADMIN) {
    throw new Error('Forbidden: You do not have permission to change user roles.');
  }
  
  const userToUpdate = MOCK_USERS.find(u => u.id === userId);
  if (!userToUpdate) {
    throw new Error('User not found.');
  }
  
  // Business logic: Admin cannot change their own role.
  if (currentUser.id === userId) {
      throw new Error('Admins cannot change their own role.');
  }

  userToUpdate.role = newRole;
  
  return {...userToUpdate}; // Return a copy of the updated user
};


// WRITE operations have RBAC checks
export const createPost = async (title: string, content: string, author: User): Promise<Post> => {
  await delay(500);
  if (![Role.ADMIN, Role.EDITOR].includes(author.role)) {
    throw new Error('Forbidden: You do not have permission to create posts.');
  }
  const newPost: Post = {
    id: `post-${Date.now()}`,
    title,
    content,
    authorId: author.id,
    authorName: author.name,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  MOCK_POSTS.unshift(newPost);
  return newPost;
};

export const updatePost = async (postId: string, title: string, content: string, user: User): Promise<Post> => {
    await delay(500);
    const postIndex = MOCK_POSTS.findIndex(p => p.id === postId);
    if (postIndex === -1) {
        throw new Error('Post not found');
    }

    const post = MOCK_POSTS[postIndex];

    // RBAC Check: Admin can edit any post. Editor can only edit their own.
    if (user.role !== Role.ADMIN && post.authorId !== user.id) {
        throw new Error('Forbidden: You can only edit your own posts.');
    }

    const updatedPost = { ...post, title, content, updatedAt: new Date().toISOString() };
    MOCK_POSTS[postIndex] = updatedPost;
    return updatedPost;
};


export const deletePost = async (postId: string, user: User): Promise<{ id: string }> => {
  await delay(500);
  const postIndex = MOCK_POSTS.findIndex(p => p.id === postId);

  if (postIndex === -1) {
    throw new Error('Post not found');
  }

  const postToDelete = MOCK_POSTS[postIndex];

  // RBAC Check: Admin can delete any post. Editor can only delete their own.
  const isAdmin = user.role === Role.ADMIN;
  const isOwner = postToDelete.authorId === user.id;

  if (!isAdmin && !isOwner) {
    throw new Error('Forbidden: You can only delete your own posts.');
  }

  // Mutate the array in place using splice. This is consistent with other
  // update functions in this mock API and avoids module-level state issues.
  MOCK_POSTS.splice(postIndex, 1);
  return { id: postId };
};